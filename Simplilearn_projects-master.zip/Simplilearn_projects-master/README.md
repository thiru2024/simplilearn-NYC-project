# Simplilearn_projects
Project done when taking the  data science wih Python course with Simplilearn
